package action.BO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import action.dao.ActionTable;
import action.dao.singlton.DBConnection;
import action.model.ActionModel;
import customer.service.CustomerService;

public class GetAction {

	static List<ActionModel> list = new ArrayList<ActionModel>();
	static HashMap<String, List<ActionModel>> hashList = new HashMap<String, List<ActionModel>>();

	public void getActionCustomer() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {

			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement("call GET_ACTIONS");

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				ActionModel actionModel = new ActionModel();

				// TODO Fetch the Data From ResultSet
				int id = resultSet.getInt("ID");
				String actionType = resultSet.getString("action_type");
				int isRead = resultSet.getInt("Is_Read");
				String customerId = resultSet.getString("customer_id");

				// TODO Set The Data Into actionModel
				actionModel.setId(id);
				actionModel.setActionType(actionType);
				actionModel.setIsRead(isRead);
				actionModel.setCustomerId(customerId);

				// TODO groupByActionType
				list.add(actionModel);
				hashList = groupByActionType(list);

				// TODO Method For Check Type Of Action And save it in the spacific List
//				setDataOnList(actionModel);

				// TODO Method For Update Action Table update (Is_Read && Creation_date)
				ActionTable actionTable = new ActionTable();
				actionTable.updateActionCustomer(id);

			}

			// TODO Method For Update Customer Table
			if (!hashList.isEmpty())
				CustomerService.customerStart(hashList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			resultSet.close();
			preparedStatement.close();
		}

//		if (!hashList.isEmpty()) {
//			for (int i = 0; i < hashList.get("working").size(); i++) {
//			System.out.println(hashList);
//
//			}
//	}
//		}
//
//		System.out.println("===================================================");
		hashList.clear();

//		activate.clear();
//		suspend.clear();
//		terminate.clear();
	}

//	public static void setDataOnList(ActionModel ActionModel) {
//
//		String actionType = ActionModel.getActionType();
//
//		if (actionType.equals("activate")) {
//			activate.add(ActionModel);
//		} else if (actionType.equals("suspend")) {
//			suspend.add(ActionModel);
//		} else if (actionType.equals("terminate")) {
//			terminate.add(ActionModel);
//		}
//	}

	public static HashMap<String, List<ActionModel>> groupByActionType(List<ActionModel> listAction) {

		HashMap<String, List<ActionModel>> groupedElements = new HashMap<String, List<ActionModel>>();

		// Iterate through the input list of elements
		for (ActionModel action : listAction) {
			// Get the action type of the current element
			String actionType = action.getActionType();

			if (groupedElements.containsKey(actionType)) {
				// If it does, add the element to the existing list
				groupedElements.get(actionType).add(action);
			} else {
				// If it doesn't, create a new list and add the element to it
				List<ActionModel> newList = new ArrayList<ActionModel>();
				newList.add(action);
				groupedElements.put(actionType, newList);
			}
		}

		return groupedElements;
	}

}
