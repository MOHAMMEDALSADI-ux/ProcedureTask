package action.BO.singlton;

import java.sql.Connection;
import java.sql.DriverManager;

import mainProject.Main;

public class DBConnection {

	private static DBConnection instance;
	private String url = Main.datasource.getProperty("url");
	private String username = Main.datasource.getProperty("DatabaseUser");
	private String pass = Main.datasource.getProperty("DatabasePass");

	private DBConnection() {

		try {
			Class.forName(Main.datasource.getProperty("driver"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws Exception {
		if (instance == null) {
			instance = new DBConnection();
			System.out.println(" Connection  - - - - - - - -  New DBConnection created");
		}

		try {
			return DriverManager.getConnection(instance.url, instance.username, instance.pass);
		} catch (Exception e) {
			throw e;
		}
	}

	public static void closeConnection(Connection connection) {
		try {
			if (connection != null) {
				connection.close();
				connection = null;
				System.out.println(" Connection  - - - - - - - -  DBConnection Close");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
