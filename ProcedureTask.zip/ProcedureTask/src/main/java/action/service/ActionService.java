package action.service;

import java.sql.SQLException;

import action.BO.GetAction;

public class ActionService {

	static public void actionStart() throws SQLException {

		GetAction action = new GetAction();
		action.getActionCustomer();

	}
}
