package action.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import action.dao.singlton.DBConnection;

public class ActionTable {

	// TODO Method For Update Customer Information From action Table
	public void updateActionCustomer(int id) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement("call UPDATE_ACTIONS(?)");

			preparedStatement.setInt(1, id);

			preparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
		}
	}

}
