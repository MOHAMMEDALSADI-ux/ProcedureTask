package action.model;

public class ActionModel {

	private int id;
	private String actionType;
	private int isRead;
	private String customerId;

	public ActionModel(int id, String actionType, int isRead, String customerId) {
		super();
		this.id = id;
		this.actionType = actionType;
		this.isRead = isRead;
		this.customerId = customerId;
	}

	public ActionModel() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public int getIsRead() {
		return isRead;
	}

	public void setIsRead(int isRead) {
		this.isRead = isRead;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "ActionModel [id=" + id + ", actionType=" + actionType + ", isRead=" + isRead + ", customerId="
				+ customerId + "]";
	}

}
