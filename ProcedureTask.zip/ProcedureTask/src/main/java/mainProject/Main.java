package mainProject;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import action.service.ActionService;

public class Main {

	public static Properties datasource;
	public static Properties application;

	static BufferedInputStream bufferedInputStream = null;
	static FileInputStream fileInputStream = null;

	static {

		datasource = new Properties();
		application = new Properties();

		try {

			// Read datasource Propertie File
			String dataSource = "C:\\Users\\m.alsadi\\eclipse-workspace\\ProcedureTask\\src\\main\\resources\\datasource.properties";
			datasource.load(readFiles(dataSource));

			// Read application properties File
			String applocation = "C:\\Users\\m.alsadi\\eclipse-workspace\\ProcedureTask\\src\\main\\resources\\application.properties";
			application.load(readFiles(applocation));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			try {
				fileInputStream.close();
				bufferedInputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) throws SQLException, InterruptedException {

		int sleep = Integer.parseInt(Main.application.getProperty("sleep"));

		while (true) {

			ActionService.actionStart();

			Thread.sleep(sleep);
		}
	}

	public static BufferedInputStream readFiles(String filePath) throws IOException {

		try {

			fileInputStream = new FileInputStream(filePath);
			bufferedInputStream = new BufferedInputStream(fileInputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bufferedInputStream;

	}
}
