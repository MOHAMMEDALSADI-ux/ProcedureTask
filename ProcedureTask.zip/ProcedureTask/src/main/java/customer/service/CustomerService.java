package customer.service;

import java.util.HashMap;
import java.util.List;
import action.model.ActionModel;
import customer.BO.ThreadPoolManager;

public class CustomerService {

	static public void customerStart(HashMap<String, List<ActionModel>> hashList)
			throws Exception {

		ThreadPoolManager manage = new ThreadPoolManager();
		manage.typeOfList(hashList);

	}
}
