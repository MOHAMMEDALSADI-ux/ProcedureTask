package customer.service;

import java.util.List;
import action.model.ActionModel;
import customer.DAO.ThreadPoolManager;

public class CustomerService {

	static public void customerStart(List<ActionModel> activate, List<ActionModel> suspend, List<ActionModel> terminate)
			throws Exception {

		ThreadPoolManager manage = new ThreadPoolManager();
		manage.typeOfList(activate, suspend, terminate);

	}
}
