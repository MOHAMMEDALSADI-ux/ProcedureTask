package customer.DAO;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import mainProject.Main;

public class ActivatePool {

	private static int fixedThreadPool = Integer.parseInt(Main.application.getProperty("newFixedThreadPool"));

	public static ThreadPoolExecutor getActivatePool(ThreadPoolExecutor activatePool) {

		try {
			if (activatePool == null) {
				activatePool = (ThreadPoolExecutor) Executors.newFixedThreadPool(fixedThreadPool);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return activatePool;

	}

	public static ThreadPoolExecutor getSuspendPool(ThreadPoolExecutor suspendPool) {

		try {
			if (suspendPool == null) {
				suspendPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(fixedThreadPool);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return suspendPool;

	}

	public static ThreadPoolExecutor getTerminatePool(ThreadPoolExecutor terminatePool) {

		try {
			if (terminatePool == null) {
				terminatePool = (ThreadPoolExecutor) Executors.newFixedThreadPool(fixedThreadPool);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return terminatePool;

	}
}
