package customer.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.mysql.cj.x.protobuf.MysqlxCrud.Update;

import java.sql.Connection;
import java.sql.PreparedStatement;
import action.dao.singlton.DBConnection;
import action.model.ActionModel;

public class UpdateCustomer {

	static Connection connection = null;

	static ActionModel customerAction;

	public static void updateAll(ActionModel actionModel) throws Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		boolean status = false;
		String actionStatus = "";
		int id = 0;

		try {

			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement("call UPDATE_USER(? , ? , ? )");

			if (actionModel.getCustomerId() != null) {
				preparedStatement.setInt(1, actionModel.getIsRead());
				preparedStatement.setString(2, actionModel.getActionType());
				preparedStatement.setString(3, actionModel.getCustomerId());

				id = actionModel.getId();
				status = preparedStatement.execute();
				if (status == true) {
					actionStatus = "failed";
				} else if (status == false) {
					actionStatus = "success";
				}

				if (!actionStatus.isEmpty() && id != 0) {
					statusUpdate(actionStatus, id);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
		}

	}

	public static void statusUpdate(String actionStatus, int id) throws SQLException {

		PreparedStatement preparedStatement = null;

		try {

			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement("call UPDATE_STATUS (? , ?)");

			preparedStatement.setString(1, actionStatus);
			preparedStatement.setInt(2, id);

			preparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
		}
	}

}

//public static boolean userExists(int customerId) {
//
//	boolean exists = false;
//
//	try {
//
//		Connection connection = DBConnection.getConnection();
//
//		PreparedStatement preparedStatement = connection
//				.prepareStatement("SELECT * FROM customer WHERE ID = " + customerId + "");
//
//		ResultSet resultSet = preparedStatement.executeQuery();
//
//		if (resultSet.next()) {
//			exists = true;
//		} else {
//			exists = false;
//		}
//
//		resultSet.close();
//		preparedStatement.close();
//
//	} catch (Exception e) {
//		e.printStackTrace();
//	}
//
//	return exists;
//
//}
