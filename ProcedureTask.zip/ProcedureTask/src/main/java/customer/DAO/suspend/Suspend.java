package customer.DAO.suspend;

import java.util.ArrayList;
import java.util.List;

import action.model.ActionModel;
import customer.BO.UpdateCustomer;

public class Suspend implements Runnable {

	List<ActionModel> suspend = new ArrayList<ActionModel>();

	public Suspend(List<ActionModel> suspend) {
		this.suspend = suspend;
	}

	public void run() {

		try {

			for (int i = 0; i < suspend.size(); i++) {
				int number = suspend.get(i).getIsRead();
				String status = suspend.get(i).getActionType();
				String customerId = suspend.get(i).getCustomerId();
				int id = suspend.get(i).getId();

				UpdateCustomer.update(number, status, customerId , id);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
