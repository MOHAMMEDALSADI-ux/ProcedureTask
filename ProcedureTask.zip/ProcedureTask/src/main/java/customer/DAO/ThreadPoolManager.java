package customer.DAO;

import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import action.model.ActionModel;
import customer.DAO.activate.Activate;
import customer.DAO.suspend.Suspend;
import customer.DAO.terminate.Terminate;
import mainProject.Main;

public class ThreadPoolManager {

	ThreadPoolExecutor activatePool;
	ThreadPoolExecutor suspendPool;
	ThreadPoolExecutor terminatePool;

	public void typeOfList(List<ActionModel> activate, List<ActionModel> suspend, List<ActionModel> terminate)
			throws Exception {

		activatePool = ActivatePool.getActivatePool(activatePool);
		suspendPool = ActivatePool.getSuspendPool(suspendPool);
		terminatePool = ActivatePool.getTerminatePool(terminatePool);

		if (!activate.isEmpty()) {
			activatePool.submit(new Activate(activate));
		}

		if (!suspend.isEmpty()) {
			suspendPool.submit(new Suspend(suspend));
		}

		if (!terminate.isEmpty()) {
			terminatePool.submit(new Terminate(terminate));
		}

		Thread.sleep(Integer.parseInt(Main.application.getProperty("sleep")));
	}

}
