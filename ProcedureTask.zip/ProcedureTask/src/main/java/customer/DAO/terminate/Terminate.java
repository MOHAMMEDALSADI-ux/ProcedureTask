package customer.DAO.terminate;

import java.util.ArrayList;
import java.util.List;

import action.model.ActionModel;
import customer.BO.UpdateCustomer;

public class Terminate implements Runnable {

	List<ActionModel> terminate = new ArrayList<ActionModel>();

	public Terminate(List<ActionModel> terminate) {
		this.terminate = terminate;
	}

	public void run() {

		try {

			for (int i = 0; i < terminate.size(); i++) {

				int number = terminate.get(i).getIsRead();
				String status = terminate.get(i).getActionType();
				String customerId = terminate.get(i).getCustomerId();
				int id = terminate.get(i).getId();

				UpdateCustomer.update(number, status, customerId, id);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
