package customer.DAO.activate;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import action.model.ActionModel;
import customer.BO.UpdateCustomer;

public class Activate implements Runnable {

	List<ActionModel> activate = new ArrayList<ActionModel>();

	public Activate(List<ActionModel> activate) {
		this.activate = activate;
	}

	public void run() {

		try {

			for (int i = 0; i < activate.size(); i++) {

				int number = activate.get(i).getIsRead();
				String status = activate.get(i).getActionType();
				String customerId = activate.get(i).getCustomerId();
				int id = activate.get(i).getId();

				UpdateCustomer.update(number, status, customerId, id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
