package customer.BO.activate;

import action.model.ActionModel;
import customer.DAO.UpdateCustomer;

public class Activate implements Runnable {

	ActionModel actionModel;

	public Activate(ActionModel actionModel) {
		this.actionModel = actionModel;
	}

	public void run() {

		try {
			UpdateCustomer.updateAll(actionModel);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
