package customer.BO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import action.BO.singlton.DBConnection;

public class UpdateCustomer {

	static Connection connection = null;
	static PreparedStatement preparedStatement = null;

	public static void update(int number, String status, String customerId, int id) throws SQLException {

		String actionStatus = "";

		try {

			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement("call UPDATE_USER(? , ? , ? )");

			preparedStatement.setInt(1, number);
			preparedStatement.setString(2, status);
			preparedStatement.setInt(3, Integer.parseInt(customerId.trim()));

			preparedStatement.executeUpdate();

			actionStatus = "Success";
		} catch (Exception e) {
			e.printStackTrace();
			actionStatus = "Faield";
		} finally {
			statusUpdate(actionStatus, id);
			preparedStatement.close();
		}

	}

	public static void statusUpdate(String actionStatus, int id) throws SQLException {

		try {

			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement("call UPDATE_STATUS (? , ?)");

			preparedStatement.setString(1, actionStatus);
			preparedStatement.setInt(2, id);

			preparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
