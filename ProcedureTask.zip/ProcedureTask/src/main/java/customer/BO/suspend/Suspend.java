package customer.BO.suspend;

import java.util.ArrayList;
import java.util.List;

import action.model.ActionModel;
import customer.DAO.UpdateCustomer;

public class Suspend implements Runnable {

	List<ActionModel> suspend = new ArrayList<ActionModel>();

	public Suspend(List<ActionModel> suspend) {
		this.suspend = suspend;
	}

	public void run() {

		try {

//			if (!suspend.isEmpty())
//				UpdateCustomer.update(suspend);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
