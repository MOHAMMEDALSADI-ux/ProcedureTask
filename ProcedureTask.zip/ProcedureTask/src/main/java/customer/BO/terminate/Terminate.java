package customer.BO.terminate;

import java.util.ArrayList;
import java.util.List;

import action.model.ActionModel;
import customer.DAO.UpdateCustomer;

public class Terminate implements Runnable {

	List<ActionModel> terminate = new ArrayList<ActionModel>();

	public Terminate(List<ActionModel> terminate) {
		this.terminate = terminate;
	}

	public void run() {

		try {

//			if (!terminate.isEmpty())
//				UpdateCustomer.update(terminate);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
