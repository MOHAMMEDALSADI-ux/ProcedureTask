package customer.BO;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import javax.swing.Action;

import action.model.ActionModel;
import customer.BO.activate.Activate;
import mainProject.Main;

public class ThreadPoolManager {

	ThreadPoolExecutor activatePool = null;
	ThreadPoolExecutor suspendPool = null;
	ThreadPoolExecutor terminatePool = null;

	ExecutorService Service = null;

	List<ActionModel> listActivate = new ArrayList<ActionModel>();
	List<ActionModel> listSuspend = new ArrayList<ActionModel>();
	List<ActionModel> listTerminate = new ArrayList<ActionModel>();

	// -----------------

	public void typeOfList(HashMap<String, List<ActionModel>> hashList) throws Exception {

		// ------------------------------

		Service = Executors.newCachedThreadPool();

		// activate
		if (hashList.containsKey("activate")) {
			List<ActionModel> listActivate = hashList.get("activate");
			if (!listActivate.isEmpty()) {
				for (int i = 0; i < listActivate.size(); i++) {
					Service.submit(new Activate(listActivate.get(i)));
				}
			}
		}
		// suspend
		if (hashList.containsKey("suspend")) {
			List<ActionModel> listSuspend = hashList.get("suspend");
			if (!listSuspend.isEmpty()) {
				for (int i = 0; i < listSuspend.size(); i++) {
					Service.submit(new Activate(listSuspend.get(i)));
				}
			}
		}
		// terminate
		if (hashList.containsKey("terminate")) {
			List<ActionModel> listTerminate = hashList.get("terminate");
			if (!listTerminate.isEmpty()) {
				for (int i = 0; i < listTerminate.size(); i++) {
					Service.submit(new Activate(listTerminate.get(i)));
				}
			}
		}
		// working
		if (hashList.containsKey("working")) {
			List<ActionModel> listView = hashList.get("working");
			if (!listView.isEmpty()) {
				for (int i = 0; i < listView.size(); i++) {
					Service.submit(new Activate(listView.get(i)));
				}
			}
		}
		// pending
		if (hashList.containsKey("pending")) {
			List<ActionModel> listView = hashList.get("pending");
			if (!listView.isEmpty()) {
				for (int i = 0; i < listView.size(); i++) {
					Service.submit(new Activate(listView.get(i)));
				}
			}
		}

		// Add any other code here that you want to execute after submitting the tasks
		// ...
		// Make sure to shutdown the thread pool once you're done using it
//		Service.shutdown();
	}

}
